# Form Test Task  

A Pen created on CodePen.

Original URL: [https://codepen.io/Pinchez-Coder/pen/JoYeyab](https://codepen.io/Pinchez-Coder/pen/JoYeyab).

Building codes that make the form functionable publicly